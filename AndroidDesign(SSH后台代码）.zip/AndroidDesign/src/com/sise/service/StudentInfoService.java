package com.sise.service;

import java.util.List;

import com.sise.pojo.Student;

public interface StudentInfoService {

	List<Student> allStudent();
}
